package com.capstone.cashflowmate.model

data class RegistrationData(
    val fullname: String,
    val email: String,
    val password: String,
    val address: String
)
